import eli5
import sklearn
import CometML
from eli5.sklearn import PermutationImportance
from sklearn.svm import SVC
from sklearn.datasets import make_classification
from sklearn.feature_selection import SelectFromModel
from sklearn import model_selection
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from sklearn.neural_network import MLPRegressor
from sklearn.metrics import r2_score
import numpy as np

dataframe = pd.read_csv('C:/ddr_read/ISPD4/fpgaeg2.csv')
print(dataframe.head(5))

array = dataframe.values
# separate array into input and output components
X = array[:,3:13]
y = array[:,14]
scaler = MinMaxScaler(feature_range=(-1, 1))
rescaledX = scaler.fit_transform(X)

X_train, X_test, y_train, y_test = model_selection.train_test_split(X, y, test_size=0.35, random_state=10)
print("x shape=",X_train.shape)
print("y shape=",y_test.shape)

a=np.array(X_train)
b=np.array(y_train)
df11 = pd.DataFrame(a,  b)
print(df11.head(5))
df11.to_csv("C:/ddr_read/ISPD4/fpgaeg2_prediction.csv", index=True)

#df = pd.DataFrame({"Y actual" : a, "Y predict" : b})

'''
train_m=np.concatenate((X_train, y_train.T), axis=1)

train_m=np.concatenate((train_m, y_train), axis=1)

test_m=np.concatenate((X_test, y_test), axis=1)
'''



clf = sklearn.ensemble.RandomForestRegressor(n_estimators=97, criterion='mse', max_depth=10,
                                                     min_samples_split=10, min_samples_leaf=0.0002835320,
                                                     max_features='auto',
                                                     max_leaf_nodes=149, bootstrap=True, oob_score=False, n_jobs=1,
                                                     random_state=10, verbose=False)
clf.fit(X_train, y_train)
y_predict = clf.predict(X_test)

a1=np.array(X_test)
b1=np.array(y_predict)
df12 = pd.DataFrame(a1,  b1)
print(df12.head(5))
df13=df11.append(df12)
print(df13.head(5))
df13.to_csv("C:/ddr_read/ISPD4/fpgaeg2_test.csv", index=True)
print('R2 score validation %.5f' % r2_score(y_test, y_predict))
'''
test_predicted=np.concatenate((test_m, y_predict), axis=1)
final_matrix= np.concatenate((test_predicted, train_m), axis=0)
np.savetxt('C:/ddr_read/ISPD4/test.csv',train_m,delimiter=",")
'''
